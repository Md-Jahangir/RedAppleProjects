System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, resources, Vec3, director, Constant, GameEvents, GridController, PieceShapes, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, GameManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfConstant(extras) {
    _reporterNs.report("Constant", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameEvents(extras) {
    _reporterNs.report("GameEvents", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGridController(extras) {
    _reporterNs.report("GridController", "./GridController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPieceShapes(extras) {
    _reporterNs.report("PieceShapes", "./PieceShapes", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      resources = _cc.resources;
      Vec3 = _cc.Vec3;
      director = _cc.director;
    }, function (_unresolved_2) {
      Constant = _unresolved_2.Constant;
      GameEvents = _unresolved_2.GameEvents;
    }, function (_unresolved_3) {
      GridController = _unresolved_3.GridController;
    }, function (_unresolved_4) {
      PieceShapes = _unresolved_4.PieceShapes;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "34584PWaOtFeJ94gRBcF/GT", "GameManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'error', 'JsonAsset', 'Node', 'Prefab', 'instantiate', 'Asset', 'tween', 'resources', 'UITransform', 'Vec3', 'Rect', 'log', 'director']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameManager", GameManager = (_dec = ccclass('GameManager'), _dec2 = property(Node), _dec3 = property(_crd && PieceShapes === void 0 ? (_reportPossibleCrUseOfPieceShapes({
        error: Error()
      }), PieceShapes) : PieceShapes), _dec4 = property(Prefab), _dec(_class = (_class2 = class GameManager extends Component {//#endregion

        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "gridControllerNode", _descriptor, this);

          this.gridControllerScript = void 0;
          this.currentLevel = 0;

          _initializerDefineProperty(this, "pieceShape", _descriptor2, this);

          _initializerDefineProperty(this, "snapDistance", _descriptor3, this);

          _initializerDefineProperty(this, "tilePrefab", _descriptor4, this);
        }

        onLoad() {
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.on((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_END, this.OnPieceShapeTouchEnd, this);
          this.gridControllerScript = this.gridControllerNode.getComponent(_crd && GridController === void 0 ? (_reportPossibleCrUseOfGridController({
            error: Error()
          }), GridController) : GridController);
        }

        start() {
          this.LoadLevelJson();
        }

        //#region - Set the level
        SetLevel() {
          if (this.currentLevel < (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).MAX_LEVEL) {
            this.currentLevel++;
          }
        }

        //#endregion
        //#region - Check if all levels complete then go menu else go the next level
        async GotoNextLevel() {
          if (this.currentLevel == (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).MAX_LEVEL) {
            director.loadScene("TitleScene");
          }

          await this.LoadNextLevel();
        }

        //#endregion
        //#region - Load the next level 
        async LoadNextLevel(_isRetry) {
          if (!_isRetry) this.SetLevel();
          const levelData = (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).RAW_JSON_FILE.Levels[0][`Level${this.currentLevel}`];
          await this.ResetAll();
          await this.gridControllerScript.SetBoardDataFromJson(levelData);
          await this.spawnAllPieces(levelData);
        }

        //#endregion
        //#region - Reset all (grid,shapes) 
        async ResetAll() {
          this.gridControllerScript.ResetGrid();
          this.pieceShape.ClearAllShapes();
        }

        //#endregion
        //#region - Load level json data
        LoadLevelJson() {
          resources.load("LevelData", async (err, assets) => {
            if (!err) {
              (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
                error: Error()
              }), Constant) : Constant).RAW_JSON_FILE = assets["json"];
              this.SetLevel();
              await this.CreateBoardAndGrid();
            }
          });
        }

        //#endregion
        //#region - Create the board with jspn data
        async CreateBoardAndGrid() {
          const levelData = (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).RAW_JSON_FILE.Levels[0][`Level${this.currentLevel}`];
          await this.gridControllerScript.SetBoardDataFromJson(levelData);
          await this.spawnAllPieces(levelData);
        }

        //#endregion
        //#region - When dropped a shapes to the grid then check it will fit or not and level complete checking
        OnPieceShapeTouchEnd(piece) {
          try {
            const gridItems = this.gridControllerScript.GetAllGridItems();
            const snapThreshold = this.snapDistance;
            const tileNodes = piece.children.length ? piece.children.slice() : [];
            const mapping = [];

            if (tileNodes.length === 0) {
              this.pieceShape.ResetToOriginal(piece);
              return;
            }

            for (let t = 0; t < tileNodes.length; t++) {
              const tile = tileNodes[t];
              const tileWorld = tile.worldPosition;
              let best = null;
              let bestDist = Number.MAX_VALUE;

              for (let i = 0; i < gridItems.length; i++) {
                const it = gridItems[i];
                const d = Vec3.distance(tileWorld, it.node.worldPosition);

                if (d < bestDist) {
                  bestDist = d;
                  best = it;
                }
              }

              if (!best || bestDist > snapThreshold) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }

              mapping.push({
                tile,
                row: best.row,
                col: best.col,
                cellNode: best.node,
                dist: bestDist
              });
            }

            const used = new Set();

            for (const m of mapping) {
              const key = `${m.row},${m.col}`;

              if (used.has(key)) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }

              used.add(key);
            }

            for (const m of mapping) {
              if (this.gridControllerScript.IsCellOccupied(m.row, m.col)) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }
            }

            for (const m of mapping) {
              m.tile.setWorldPosition(m.cellNode.worldPosition);
              this.gridControllerScript.MarkGridOccupied(m.row, m.col);
            }

            if (this.pieceShape.DisableParticularShapes) {
              try {
                this.pieceShape.DisableParticularShapes(piece);
              } catch (e) {
                /* safe */
              }
            } else {}

            this.scheduleOnce(() => {
              const res = this.gridControllerScript.CheckIfGridFull();

              if (res) {
                this.OnLevelComplete();
              }
            }, 0.05);
          } catch (err) {
            console.error("Error in OnPieceShapeTouchEnd:", err);
            this.pieceShape.ResetToOriginal(piece);
          }
        }

        //#endregion
        //#region - On level complete load the next level and show popup if any
        OnLevelComplete() {
          this.scheduleOnce(() => {
            this.GotoNextLevel();
          }, 0.5);
        }

        //#endregion
        //#region - Spawn all the shapes from the json data
        async spawnAllPieces(levelData) {
          if (!levelData || !levelData.shape_pieces || !levelData.shape_pieces.possible_shapes) return;
          const possibleShapes = levelData.shape_pieces.possible_shapes;
          this.pieceShape.CreateShapeByType(possibleShapes);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gridControllerNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "pieceShape", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "snapDistance", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 80;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "tilePrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=dc10b9f9fd8a4544c6bb2e28c71f00ef7d81af05.js.map