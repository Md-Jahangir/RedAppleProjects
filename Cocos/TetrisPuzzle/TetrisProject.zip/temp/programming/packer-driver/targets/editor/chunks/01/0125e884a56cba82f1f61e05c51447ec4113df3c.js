System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, UITransform, Color, instantiate, Layout, SpriteFrame, Sprite, Label, GridCell, Utils, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, GridController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGridCell(extras) {
    _reporterNs.report("GridCell", "./GridCell", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "./utils/Utils", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      UITransform = _cc.UITransform;
      Color = _cc.Color;
      instantiate = _cc.instantiate;
      Layout = _cc.Layout;
      SpriteFrame = _cc.SpriteFrame;
      Sprite = _cc.Sprite;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      GridCell = _unresolved_2.GridCell;
    }, function (_unresolved_3) {
      Utils = _unresolved_3.Utils;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "87a3dfXRkRB6rzQYe28dwj2", "GridController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'UITransform', 'Color', 'instantiate', 'Vec3', 'Layout', 'SpriteFrame', 'Sprite', 'Label']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GridController", GridController = (_dec = ccclass('GridController'), _dec2 = property(Prefab), _dec3 = property(Prefab), _dec4 = property(Node), _dec5 = property([SpriteFrame]), _dec(_class = (_class2 = class GridController extends Component {//#endregion

        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "tilePrefab", _descriptor, this);

          _initializerDefineProperty(this, "gridColumns", _descriptor2, this);

          _initializerDefineProperty(this, "gridRows", _descriptor3, this);

          _initializerDefineProperty(this, "gridCellPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "tableBg", _descriptor5, this);

          _initializerDefineProperty(this, "tableBgFrameArray", _descriptor6, this);

          this.gridCells = [];
        }

        //#region - Set Board image ,grid deatils from json
        async SetBoardDataFromJson(_jsonData) {
          try {
            this.gridRows = _jsonData.grid.row;
            this.gridColumns = _jsonData.grid.col;
            await this.CreateBoard(_jsonData);
          } catch (error) {
            console.error("Error in SetBoardDataFromJson:", error);
          }
        }

        //#endregion
        //#region - Create the board
        async CreateBoard(jsonData) {
          try {
            const bgFrame = this.tableBgFrameArray.find(sf => sf.name === jsonData.board_bg);

            if (bgFrame) {
              this.tableBg.getComponent(Sprite).spriteFrame = bgFrame;
              await this.CalculateGridStartPosition();
              await this.GenerateGrid(this.gridRows, jsonData);

              if (jsonData.target_shape) {
                this.PlaceTargetShape(jsonData.target_shape);
              }
            } else {}
          } catch (error) {
            console.error("Error in CreateBoard:", error);
          }
        }

        //#endregion
        //#region - Calculate grid position to place
        async CalculateGridStartPosition() {
          return new Promise(resolve => {
            try {
              const itemSize = this.gridCellPrefab.data.getComponent(UITransform).contentSize;
              const uiComponent = this.node.getComponent(UITransform);
              const layoutComponent = this.node.getComponent(Layout);
              const tempX = this.gridRows * itemSize.x;
              const tempY = this.gridColumns * itemSize.x;
              uiComponent.width = tempX + layoutComponent.paddingLeft;
            } catch (error) {
              console.error("Error in CalculateGridStartPosition:", error);
            }

            resolve();
          });
        }

        //#endregion
        //#region - Generate grid
        async GenerateGrid(rows, jsonData) {
          try {
            this.node.removeAllChildren();
            this.gridCells = [];

            for (let r = 0; r < rows; r++) {
              this.gridCells[r] = [];

              for (let c = 0; c < this.gridColumns; c++) {
                const gridCellNode = instantiate(this.gridCellPrefab);
                gridCellNode.children[0].getComponent(Label).string = `${r}${c}`;
                this.node.addChild(gridCellNode);
                const gridCellScript = gridCellNode.getComponent(_crd && GridCell === void 0 ? (_reportPossibleCrUseOfGridCell({
                  error: Error()
                }), GridCell) : GridCell);

                if (gridCellScript) {
                  gridCellScript.SetGridPosition(r, c);
                  this.gridCells[r][c] = gridCellScript;
                }
              }
            }
          } catch (error) {
            console.error("Error in GenerateGrid:", error);
          }
        }

        //#endregion
        //#region - Set any shapes in the grid first
        PlaceTargetShape(targetShapes) {
          if (!targetShapes || targetShapes.length === 0) return;

          for (const targetShape of targetShapes) {
            if (!targetShape || !targetShape.type || !targetShape.start_position) continue;
            const {
              type,
              start_position
            } = targetShape;
            const layout = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
              error: Error()
            }), Utils) : Utils).GetShapeLayout(type);

            if (!layout || layout.length === 0) {
              continue;
            }

            const randomColor = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
              error: Error()
            }), Utils) : Utils).GetRandomColor();

            for (let r = 0; r < layout.length; r++) {
              for (let c = 0; c < layout[r].length; c++) {
                if (layout[r][c] === 1) {
                  var _this$gridCells$row;

                  const row = start_position.row + r;
                  const col = start_position.col + c;
                  const cell = (_this$gridCells$row = this.gridCells[row]) == null ? void 0 : _this$gridCells$row[col];
                  if (!cell) continue;
                  const shapeTile = instantiate(this.tilePrefab);
                  cell.node.addChild(shapeTile);
                  const sprite = shapeTile.getComponent(Sprite);
                  if (sprite) sprite.color = new Color(randomColor[0], randomColor[1], randomColor[2]);
                  cell.SetOccupied(true);
                }
              }
            }
          }
        }

        //#endregion
        //#region - Check all the cell is occupied with the shpaes
        IsCellOccupied(row, col) {
          if (!this.gridCells[row] || !this.gridCells[row][col]) return true;
          return !!this.gridCells[row][col].IsOccupied();
        }

        //#endregion
        //#region - Check if full the grid is occupied with shapes or not
        CheckIfGridFull() {
          try {
            for (let r = 0; r < this.gridRows; r++) {
              for (let c = 0; c < this.gridColumns; c++) {
                var _this$gridCells$r;

                const cell = (_this$gridCells$r = this.gridCells[r]) == null ? void 0 : _this$gridCells$r[c];

                if (!cell || !cell.IsOccupied()) {
                  return false;
                }
              }
            }

            return true;
          } catch (error) {
            console.error("Error in CheckIfGridFull:", error);
            return false;
          }
        }

        //#endregion
        //#region - Set grid is occupied to true
        MarkGridOccupied(row, col) {
          if (this.gridCells[row] && this.gridCells[row][col]) {
            this.gridCells[row][col].SetOccupied(true);
          }
        }

        //#endregion
        //#region - Get al the grid items
        GetAllGridItems() {
          const items = [];

          for (let r = 0; r < this.gridCells.length; r++) {
            for (let c = 0; c < this.gridCells[r].length; c++) {
              const cell = this.gridCells[r][c];

              if (cell != null && cell.node) {
                items.push({
                  row: r,
                  col: c,
                  node: cell.node
                });
              }
            }
          }

          return items;
        }

        //#endregion
        //#region - Reset the grid
        ResetGrid() {
          this.node.removeAllChildren();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tilePrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "gridColumns", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 4;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "gridRows", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 3;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gridCellPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "tableBg", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "tableBgFrameArray", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0125e884a56cba82f1f61e05c51447ec4113df3c.js.map