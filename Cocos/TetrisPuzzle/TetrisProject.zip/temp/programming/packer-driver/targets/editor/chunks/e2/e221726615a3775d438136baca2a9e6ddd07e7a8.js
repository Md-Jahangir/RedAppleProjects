System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, EventTarget, Constant, _crd, GameEvents, constant;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      EventTarget = _cc.EventTarget;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fb9e76ZMYtNKb0t/IFxJcwS", "Constant", undefined);

      __checkObsolete__(['EventTarget']);

      Constant = class Constant {
        constructor() {
          this.event = new EventTarget();
          this.RAW_JSON_FILE = null;
          this.MAX_LEVEL = 4;
        }

      };

      _export("GameEvents", GameEvents = /*#__PURE__*/function (GameEvents) {
        GameEvents["ON_PIECE_SHAPES_TOUCH_START"] = "on_piece_shapes_touch_start";
        GameEvents["ON_PIECE_SHAPES_TOUCH_END"] = "on_piece_shapes_touch_end";
        GameEvents["ON_PIECE_SHAPES_TOUCH_MOVE"] = "on_piece_shapes_touch_move";
        GameEvents["ON_PIECE_SHAPES_TOUCH_CANCEL"] = "on_piece_shapes_touch_cancel";
        GameEvents["ON_GAME_OVER"] = "on_game_over";
        GameEvents["ON_LEVEL_COMPLETE"] = "on_level_complete";
        GameEvents["ON_NEXT_BUTTON_PRESSED"] = "on_next_button_pressed";
        GameEvents["ON_UPDATE_TARGET_TRAY_UI"] = "on_update_target_tray_ui";
        return GameEvents;
      }({}));

      ;

      _export("Constant", constant = new Constant());

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e221726615a3775d438136baca2a9e6ddd07e7a8.js.map