System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, Utils, _crd;

  _export("Utils", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ce912hcvbFGG6WheEJHB9tZ", "Utils", undefined);

      _export("Utils", Utils = class Utils {//#endregion

        //#region - Get the different types shapes's co-ordinate
        static GetShapeLayout(type) {
          const shapes = {
            L: [[1, 0], [1, 0], [1, 1]],
            Lflip: [[0, 1], [0, 1], [1, 1]],
            T: [[1, 1, 1], [0, 1, 0]],
            FlipT: [[0, 1], [1, 1], [0, 1]],
            Square: [[1, 1], [1, 1]],
            VLine: [[1], [1], [1], [1]],
            HLine: [[1, 1, 1, 1]],
            Z: [[1, 1, 0], [0, 1, 1]],
            S: [[0, 1, 1], [1, 1, 0]],
            Single: [[1]]
          };
          return shapes[type] || shapes.Square;
        }

        //#endregion
        //#region - Get random shapes
        static GetRandomShape() {
          const shapes = ["L", "T", "Square", "Line", "Z", "S"];
          return shapes[Math.floor(Math.random() * shapes.length)];
        }

        //#endregion
        //#region - Get random color code
        static GetRandomColor() {
          const colors = [[255, 0, 0], // red
          [0, 255, 0], // green
          [0, 0, 255], // blue
          [128, 0, 128], // purple
          [255, 255, 0], // yellow
          [165, 42, 42] // brown
          ];
          return colors[Math.floor(Math.random() * colors.length)];
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1c07a5309663b0124b28b3769eb5944f7c5a0266.js.map