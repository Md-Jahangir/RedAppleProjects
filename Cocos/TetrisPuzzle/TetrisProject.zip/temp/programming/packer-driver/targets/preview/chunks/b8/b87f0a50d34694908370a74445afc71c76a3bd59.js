System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, _dec, _class, _crd, ccclass, property, GridCell;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a318f5fz1VK9rGPR7C9r1wL", "GridCell", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GridCell", GridCell = (_dec = ccclass('GridCell'), _dec(_class = class GridCell extends Component {
        constructor() {
          super(...arguments);
          this.gridPosition = {
            row: -1,
            col: -1
          };
          this.isOccupied = false;
        }

        onLoad() {}

        //#region - Set Grid Position
        SetGridPosition(row, col) {
          this.gridPosition.row = row;
          this.gridPosition.col = col;
        }

        //#endregion
        //#region - Get Grid Position
        GetGridPosition() {
          return this.gridPosition;
        }

        //#endregion
        //#region - Return if grid is occupied
        IsOccupied() {
          return this.isOccupied;
        }

        //#endregion
        //#region - Set grid to occupied
        SetOccupied(value) {
          if (value === void 0) {
            value = true;
          }

          this.isOccupied = value;
        } //#endregion


      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b87f0a50d34694908370a74445afc71c76a3bd59.js.map