System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, UITransform, Color, instantiate, Layout, SpriteFrame, Sprite, Label, GridCell, Utils, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, GridController;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGridCell(extras) {
    _reporterNs.report("GridCell", "./GridCell", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "./utils/Utils", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      UITransform = _cc.UITransform;
      Color = _cc.Color;
      instantiate = _cc.instantiate;
      Layout = _cc.Layout;
      SpriteFrame = _cc.SpriteFrame;
      Sprite = _cc.Sprite;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      GridCell = _unresolved_2.GridCell;
    }, function (_unresolved_3) {
      Utils = _unresolved_3.Utils;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "87a3dfXRkRB6rzQYe28dwj2", "GridController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'UITransform', 'Color', 'instantiate', 'Vec3', 'Layout', 'SpriteFrame', 'Sprite', 'Label']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GridController", GridController = (_dec = ccclass('GridController'), _dec2 = property(Prefab), _dec3 = property(Prefab), _dec4 = property(Node), _dec5 = property([SpriteFrame]), _dec(_class = (_class2 = class GridController extends Component {//#endregion

        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "tilePrefab", _descriptor, this);

          _initializerDefineProperty(this, "gridColumns", _descriptor2, this);

          _initializerDefineProperty(this, "gridRows", _descriptor3, this);

          _initializerDefineProperty(this, "gridCellPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "tableBg", _descriptor5, this);

          _initializerDefineProperty(this, "tableBgFrameArray", _descriptor6, this);

          this.gridCells = [];
        }

        //#region - Set Board image ,grid deatils from json
        SetBoardDataFromJson(_jsonData) {
          var _this = this;

          return _asyncToGenerator(function* () {
            try {
              _this.gridRows = _jsonData.grid.row;
              _this.gridColumns = _jsonData.grid.col;
              yield _this.CreateBoard(_jsonData);
            } catch (error) {
              console.error("Error in SetBoardDataFromJson:", error);
            }
          })();
        }

        //#endregion
        //#region - Create the board
        CreateBoard(jsonData) {
          var _this2 = this;

          return _asyncToGenerator(function* () {
            try {
              var bgFrame = _this2.tableBgFrameArray.find(sf => sf.name === jsonData.board_bg);

              if (bgFrame) {
                _this2.tableBg.getComponent(Sprite).spriteFrame = bgFrame;
                yield _this2.CalculateGridStartPosition();
                yield _this2.GenerateGrid(_this2.gridRows, jsonData);

                if (jsonData.target_shape) {
                  _this2.PlaceTargetShape(jsonData.target_shape);
                }
              } else {}
            } catch (error) {
              console.error("Error in CreateBoard:", error);
            }
          })();
        }

        //#endregion
        //#region - Calculate grid position to place
        CalculateGridStartPosition() {
          var _this3 = this;

          return _asyncToGenerator(function* () {
            return new Promise(resolve => {
              try {
                var itemSize = _this3.gridCellPrefab.data.getComponent(UITransform).contentSize;

                var uiComponent = _this3.node.getComponent(UITransform);

                var layoutComponent = _this3.node.getComponent(Layout);

                var tempX = _this3.gridRows * itemSize.x;
                var tempY = _this3.gridColumns * itemSize.x;
                uiComponent.width = tempX + layoutComponent.paddingLeft;
              } catch (error) {
                console.error("Error in CalculateGridStartPosition:", error);
              }

              resolve();
            });
          })();
        }

        //#endregion
        //#region - Generate grid
        GenerateGrid(rows, jsonData) {
          var _this4 = this;

          return _asyncToGenerator(function* () {
            try {
              _this4.node.removeAllChildren();

              _this4.gridCells = [];

              for (var r = 0; r < rows; r++) {
                _this4.gridCells[r] = [];

                for (var c = 0; c < _this4.gridColumns; c++) {
                  var gridCellNode = instantiate(_this4.gridCellPrefab);
                  gridCellNode.children[0].getComponent(Label).string = "" + r + c;

                  _this4.node.addChild(gridCellNode);

                  var gridCellScript = gridCellNode.getComponent(_crd && GridCell === void 0 ? (_reportPossibleCrUseOfGridCell({
                    error: Error()
                  }), GridCell) : GridCell);

                  if (gridCellScript) {
                    gridCellScript.SetGridPosition(r, c);
                    _this4.gridCells[r][c] = gridCellScript;
                  }
                }
              }
            } catch (error) {
              console.error("Error in GenerateGrid:", error);
            }
          })();
        }

        //#endregion
        //#region - Set any shapes in the grid first
        PlaceTargetShape(targetShapes) {
          if (!targetShapes || targetShapes.length === 0) return;

          for (var targetShape of targetShapes) {
            if (!targetShape || !targetShape.type || !targetShape.start_position) continue;
            var {
              type,
              start_position
            } = targetShape;
            var layout = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
              error: Error()
            }), Utils) : Utils).GetShapeLayout(type);

            if (!layout || layout.length === 0) {
              continue;
            }

            var randomColor = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
              error: Error()
            }), Utils) : Utils).GetRandomColor();

            for (var r = 0; r < layout.length; r++) {
              for (var c = 0; c < layout[r].length; c++) {
                if (layout[r][c] === 1) {
                  var _this$gridCells$row;

                  var row = start_position.row + r;
                  var col = start_position.col + c;
                  var cell = (_this$gridCells$row = this.gridCells[row]) == null ? void 0 : _this$gridCells$row[col];
                  if (!cell) continue;
                  var shapeTile = instantiate(this.tilePrefab);
                  cell.node.addChild(shapeTile);
                  var sprite = shapeTile.getComponent(Sprite);
                  if (sprite) sprite.color = new Color(randomColor[0], randomColor[1], randomColor[2]);
                  cell.SetOccupied(true);
                }
              }
            }
          }
        }

        //#endregion
        //#region - Check all the cell is occupied with the shpaes
        IsCellOccupied(row, col) {
          if (!this.gridCells[row] || !this.gridCells[row][col]) return true;
          return !!this.gridCells[row][col].IsOccupied();
        }

        //#endregion
        //#region - Check if full the grid is occupied with shapes or not
        CheckIfGridFull() {
          try {
            for (var r = 0; r < this.gridRows; r++) {
              for (var c = 0; c < this.gridColumns; c++) {
                var _this$gridCells$r;

                var cell = (_this$gridCells$r = this.gridCells[r]) == null ? void 0 : _this$gridCells$r[c];

                if (!cell || !cell.IsOccupied()) {
                  return false;
                }
              }
            }

            return true;
          } catch (error) {
            console.error("Error in CheckIfGridFull:", error);
            return false;
          }
        }

        //#endregion
        //#region - Set grid is occupied to true
        MarkGridOccupied(row, col) {
          if (this.gridCells[row] && this.gridCells[row][col]) {
            this.gridCells[row][col].SetOccupied(true);
          }
        }

        //#endregion
        //#region - Get al the grid items
        GetAllGridItems() {
          var items = [];

          for (var r = 0; r < this.gridCells.length; r++) {
            for (var c = 0; c < this.gridCells[r].length; c++) {
              var cell = this.gridCells[r][c];

              if (cell != null && cell.node) {
                items.push({
                  row: r,
                  col: c,
                  node: cell.node
                });
              }
            }
          }

          return items;
        }

        //#endregion
        //#region - Reset the grid
        ResetGrid() {
          this.node.removeAllChildren();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tilePrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "gridColumns", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 4;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "gridRows", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 3;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gridCellPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "tableBg", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "tableBgFrameArray", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0125e884a56cba82f1f61e05c51447ec4113df3c.js.map