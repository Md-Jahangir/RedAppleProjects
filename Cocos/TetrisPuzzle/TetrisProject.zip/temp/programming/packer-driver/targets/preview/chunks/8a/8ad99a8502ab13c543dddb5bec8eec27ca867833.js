System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Color, instantiate, Sprite, Vec2, Vec3, UITransform, Prefab, Input, Constant, GameEvents, Utils, _dec, _dec2, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, PieceShapes;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfConstant(extras) {
    _reporterNs.report("Constant", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameEvents(extras) {
    _reporterNs.report("GameEvents", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUtils(extras) {
    _reporterNs.report("Utils", "./utils/Utils", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Color = _cc.Color;
      instantiate = _cc.instantiate;
      Sprite = _cc.Sprite;
      Vec2 = _cc.Vec2;
      Vec3 = _cc.Vec3;
      UITransform = _cc.UITransform;
      Prefab = _cc.Prefab;
      Input = _cc.Input;
    }, function (_unresolved_2) {
      Constant = _unresolved_2.Constant;
      GameEvents = _unresolved_2.GameEvents;
    }, function (_unresolved_3) {
      Utils = _unresolved_3.Utils;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c871cEw1H9MRYtqU/zZs0Px", "PieceShapes", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Color', 'instantiate', 'Sprite', 'Vec2', 'Vec3', 'UITransform', 'Prefab', 'EventTouch', 'Input', 'Layout']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PieceShapes", PieceShapes = (_dec = ccclass('PieceShapes'), _dec2 = property(Prefab), _dec(_class = (_class2 = class PieceShapes extends Component {//#endregion

        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "tilePrefab", _descriptor, this);

          _initializerDefineProperty(this, "tileSize", _descriptor2, this);

          this.tiles = [];
          this.isDragging = false;
          this.offset = new Vec2();
          this.originalPosition = new Vec3();
        }

        onLoad() {
          if (!this.node.getComponent(UITransform)) {
            this.node.addComponent(UITransform);
          }
        }

        //#region - Create single shapes
        CreateShape(pos, _shape) {
          var shapeType;
          _shape ? shapeType = _shape : shapeType = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).GetRandomShape();
          var newNode = new Node('parent');
          newNode.addComponent(UITransform).setContentSize(400, 400);
          newNode.setParent(this.node);
          newNode.setScale(0.5, 0.5);
          newNode.setPosition(pos);
          newNode.removeAllChildren();
          this.tiles = [];
          var layout = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).GetShapeLayout(shapeType);
          var randomColor = (_crd && Utils === void 0 ? (_reportPossibleCrUseOfUtils({
            error: Error()
          }), Utils) : Utils).GetRandomColor();
          var width = this.tileSize.x * layout[0].length;
          var height = this.tileSize.y * layout.length;
          var transform = newNode.getComponent(UITransform);
          transform.setContentSize(width, height);
          var xOffset = -width / 2 + this.tileSize.x / 2;
          var yOffset = height / 2 - this.tileSize.y / 2;

          for (var r = 0; r < layout.length; r++) {
            for (var c = 0; c < layout[r].length; c++) {
              if (layout[r][c] === 1) {
                var tile = instantiate(this.tilePrefab);
                tile.setParent(newNode);
                tile.setPosition(xOffset + c * this.tileSize.x, yOffset - r * this.tileSize.y);
                var sprite = tile.getComponent(Sprite);
                if (sprite) sprite.color = new Color(randomColor[0], randomColor[1], randomColor[2]);
                this.tiles.push(tile);
              }
            }
          }
        }

        //#endregion
        //#region - Create all the shapes coming from json
        CreateShapeByType(possibleShapes) {
          var spawnPos = [new Vec3(-350, -260), new Vec3(0, -260), new Vec3(350, -260), new Vec3(-350, 0), new Vec3(0, 0), new Vec3(350, 0), new Vec3(-350, 260), new Vec3(0, 260), new Vec3(350, 260)];

          for (var i = 0; i < possibleShapes.length; i++) {
            this.CreateShape(spawnPos[i], possibleShapes[i]);
          }

          this.EnableInputEvent();
        }

        //#endregion
        //#region - Enable input to the shapes
        EnableInputEvent() {
          this.node.children.forEach(child => {
            child.on(Input.EventType.TOUCH_START, this.OnTouchStart, this);
            child.on(Input.EventType.TOUCH_MOVE, this.OnTouchMove, this);
            child.on(Input.EventType.TOUCH_END, this.OnTouchEnd, this);
            child.on(Input.EventType.TOUCH_CANCEL, this.OnTouchCancel, this);
          });
        }

        //#endregion
        //#region - Disable input to the shapes
        DisableParticularShapes(currNode) {
          currNode.off(Input.EventType.TOUCH_START, this.OnTouchStart, this);
          currNode.off(Input.EventType.TOUCH_MOVE, this.OnTouchMove, this);
          currNode.off(Input.EventType.TOUCH_END, this.OnTouchEnd, this);
          currNode.on(Input.EventType.TOUCH_CANCEL, this.OnTouchCancel, this);
        }

        //#endregion
        //#region - On Touch Start
        OnTouchStart(event) {
          var currTarget = event.currentTarget;
          currTarget.setScale(1, 1);
          var uiComp = currTarget.getComponent(UITransform);
          uiComp.setAnchorPoint(0.5, 0.5);
          this.isDragging = true;
          this.originalPosition = currTarget.worldPosition.clone();
          var touchPos = event.getUILocation();
          var nodePos = currTarget.getWorldPosition();
          this.offset.set(touchPos.x - nodePos.x, touchPos.y - nodePos.y);
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.emit((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_START, currTarget);
        }

        //#endregion
        //#region - On Touch Move
        OnTouchMove(event) {
          if (!this.isDragging) return;
          var currTarget = event.currentTarget;
          var touchPos = event.getUILocation();
          currTarget.setWorldPosition(new Vec3(touchPos.x - this.offset.x, touchPos.y - this.offset.y, 0));
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.emit((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_MOVE, currTarget);
        }

        //#endregion
        //#region - On Touch End
        OnTouchEnd(event) {
          this.isDragging = false;
          var currTarget = event.currentTarget;
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.emit((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_END, currTarget);
        }

        //#endregion
        //#region - On Touch Cancel
        OnTouchCancel(event) {
          this.isDragging = false;
          var currTarget = event.currentTarget;
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.emit((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_CANCEL, currTarget);
        }

        //#endregion
        //#region - Reset To original position of the shapes
        ResetToOriginal(currNode) {
          currNode.setScale(0.5, 0.5);
          currNode.setWorldPosition(this.originalPosition);
        }

        //#endregion
        //#region - Clear all the shapes 
        ClearAllShapes() {
          this.node.removeAllChildren();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tilePrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tileSize", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return new Vec2(100, 100);
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8ad99a8502ab13c543dddb5bec8eec27ca867833.js.map