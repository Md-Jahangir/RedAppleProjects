System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Prefab, resources, Vec3, director, Constant, GameEvents, GridController, PieceShapes, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, GameManager;

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

  function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfConstant(extras) {
    _reporterNs.report("Constant", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameEvents(extras) {
    _reporterNs.report("GameEvents", "./utils/Constant", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGridController(extras) {
    _reporterNs.report("GridController", "./GridController", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPieceShapes(extras) {
    _reporterNs.report("PieceShapes", "./PieceShapes", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      resources = _cc.resources;
      Vec3 = _cc.Vec3;
      director = _cc.director;
    }, function (_unresolved_2) {
      Constant = _unresolved_2.Constant;
      GameEvents = _unresolved_2.GameEvents;
    }, function (_unresolved_3) {
      GridController = _unresolved_3.GridController;
    }, function (_unresolved_4) {
      PieceShapes = _unresolved_4.PieceShapes;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "34584PWaOtFeJ94gRBcF/GT", "GameManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'error', 'JsonAsset', 'Node', 'Prefab', 'instantiate', 'Asset', 'tween', 'resources', 'UITransform', 'Vec3', 'Rect', 'log', 'director']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameManager", GameManager = (_dec = ccclass('GameManager'), _dec2 = property(Node), _dec3 = property(_crd && PieceShapes === void 0 ? (_reportPossibleCrUseOfPieceShapes({
        error: Error()
      }), PieceShapes) : PieceShapes), _dec4 = property(Prefab), _dec(_class = (_class2 = class GameManager extends Component {//#endregion

        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "gridControllerNode", _descriptor, this);

          this.gridControllerScript = void 0;
          this.currentLevel = 0;

          _initializerDefineProperty(this, "pieceShape", _descriptor2, this);

          _initializerDefineProperty(this, "snapDistance", _descriptor3, this);

          _initializerDefineProperty(this, "tilePrefab", _descriptor4, this);
        }

        onLoad() {
          (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).event.on((_crd && GameEvents === void 0 ? (_reportPossibleCrUseOfGameEvents({
            error: Error()
          }), GameEvents) : GameEvents).ON_PIECE_SHAPES_TOUCH_END, this.OnPieceShapeTouchEnd, this);
          this.gridControllerScript = this.gridControllerNode.getComponent(_crd && GridController === void 0 ? (_reportPossibleCrUseOfGridController({
            error: Error()
          }), GridController) : GridController);
        }

        start() {
          this.LoadLevelJson();
        }

        //#region - Set the level
        SetLevel() {
          if (this.currentLevel < (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
            error: Error()
          }), Constant) : Constant).MAX_LEVEL) {
            this.currentLevel++;
          }
        }

        //#endregion
        //#region - Check if all levels complete then go menu else go the next level
        GotoNextLevel() {
          var _this = this;

          return _asyncToGenerator(function* () {
            if (_this.currentLevel == (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
              error: Error()
            }), Constant) : Constant).MAX_LEVEL) {
              director.loadScene("TitleScene");
            }

            yield _this.LoadNextLevel();
          })();
        }

        //#endregion
        //#region - Load the next level 
        LoadNextLevel(_isRetry) {
          var _this2 = this;

          return _asyncToGenerator(function* () {
            if (!_isRetry) _this2.SetLevel();
            var levelData = (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
              error: Error()
            }), Constant) : Constant).RAW_JSON_FILE.Levels[0]["Level" + _this2.currentLevel];
            yield _this2.ResetAll();
            yield _this2.gridControllerScript.SetBoardDataFromJson(levelData);
            yield _this2.spawnAllPieces(levelData);
          })();
        }

        //#endregion
        //#region - Reset all (grid,shapes) 
        ResetAll() {
          var _this3 = this;

          return _asyncToGenerator(function* () {
            _this3.gridControllerScript.ResetGrid();

            _this3.pieceShape.ClearAllShapes();
          })();
        }

        //#endregion
        //#region - Load level json data
        LoadLevelJson() {
          var _this4 = this;

          resources.load("LevelData", /*#__PURE__*/_asyncToGenerator(function* (err, assets) {
            if (!err) {
              (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
                error: Error()
              }), Constant) : Constant).RAW_JSON_FILE = assets["json"];

              _this4.SetLevel();

              yield _this4.CreateBoardAndGrid();
            }
          }));
        }

        //#endregion
        //#region - Create the board with jspn data
        CreateBoardAndGrid() {
          var _this5 = this;

          return _asyncToGenerator(function* () {
            var levelData = (_crd && Constant === void 0 ? (_reportPossibleCrUseOfConstant({
              error: Error()
            }), Constant) : Constant).RAW_JSON_FILE.Levels[0]["Level" + _this5.currentLevel];
            yield _this5.gridControllerScript.SetBoardDataFromJson(levelData);
            yield _this5.spawnAllPieces(levelData);
          })();
        }

        //#endregion
        //#region - When dropped a shapes to the grid then check it will fit or not and level complete checking
        OnPieceShapeTouchEnd(piece) {
          try {
            var gridItems = this.gridControllerScript.GetAllGridItems();
            var snapThreshold = this.snapDistance;
            var tileNodes = piece.children.length ? piece.children.slice() : [];
            var mapping = [];

            if (tileNodes.length === 0) {
              this.pieceShape.ResetToOriginal(piece);
              return;
            }

            for (var t = 0; t < tileNodes.length; t++) {
              var tile = tileNodes[t];
              var tileWorld = tile.worldPosition;
              var best = null;
              var bestDist = Number.MAX_VALUE;

              for (var i = 0; i < gridItems.length; i++) {
                var it = gridItems[i];
                var d = Vec3.distance(tileWorld, it.node.worldPosition);

                if (d < bestDist) {
                  bestDist = d;
                  best = it;
                }
              }

              if (!best || bestDist > snapThreshold) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }

              mapping.push({
                tile,
                row: best.row,
                col: best.col,
                cellNode: best.node,
                dist: bestDist
              });
            }

            var used = new Set();

            for (var m of mapping) {
              var key = m.row + "," + m.col;

              if (used.has(key)) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }

              used.add(key);
            }

            for (var _m of mapping) {
              if (this.gridControllerScript.IsCellOccupied(_m.row, _m.col)) {
                this.pieceShape.ResetToOriginal(piece);
                return;
              }
            }

            for (var _m2 of mapping) {
              _m2.tile.setWorldPosition(_m2.cellNode.worldPosition);

              this.gridControllerScript.MarkGridOccupied(_m2.row, _m2.col);
            }

            if (this.pieceShape.DisableParticularShapes) {
              try {
                this.pieceShape.DisableParticularShapes(piece);
              } catch (e) {
                /* safe */
              }
            } else {}

            this.scheduleOnce(() => {
              var res = this.gridControllerScript.CheckIfGridFull();

              if (res) {
                this.OnLevelComplete();
              }
            }, 0.05);
          } catch (err) {
            console.error("Error in OnPieceShapeTouchEnd:", err);
            this.pieceShape.ResetToOriginal(piece);
          }
        }

        //#endregion
        //#region - On level complete load the next level and show popup if any
        OnLevelComplete() {
          this.scheduleOnce(() => {
            this.GotoNextLevel();
          }, 0.5);
        }

        //#endregion
        //#region - Spawn all the shapes from the json data
        spawnAllPieces(levelData) {
          var _this6 = this;

          return _asyncToGenerator(function* () {
            if (!levelData || !levelData.shape_pieces || !levelData.shape_pieces.possible_shapes) return;
            var possibleShapes = levelData.shape_pieces.possible_shapes;

            _this6.pieceShape.CreateShapeByType(possibleShapes);
          })();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gridControllerNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "pieceShape", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "snapDistance", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 80;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "tilePrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=dc10b9f9fd8a4544c6bb2e28c71f00ef7d81af05.js.map