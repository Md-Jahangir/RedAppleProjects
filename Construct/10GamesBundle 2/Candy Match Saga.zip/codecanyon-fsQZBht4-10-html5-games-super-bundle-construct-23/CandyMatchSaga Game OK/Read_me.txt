Candy Match Saga

Thank you for buy my game, hope you enjoy
As every developer is different to another in all my games
every single line of code is full commented, so you can understand the game logic

Dont forget to read The Quick start Guide To Begin


If you have questions or need help please contact me:

pre47cher@gmail.com